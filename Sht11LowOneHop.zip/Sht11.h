#ifndef SHT11_H
#define SHT11_H

#include "message.h"

enum {
  TEST_PERIOD = 1024U,

};


typedef nx_struct msg {
  nx_am_addr_t srcID;
  nx_uint32_t seqNo;
  nx_uint16_t type;
  nx_uint16_t temp;
  nx_uint16_t humi;
  nx_uint16_t illu;
  nx_uint16_t battery;
} test_data_msg_t;

#endif // SHT11_H
