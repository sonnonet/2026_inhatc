includes Sht11;

configuration Sht11AppC { }

implementation
{
  components MainC, Sht11C, LedsC;
  components new TimerMilliC() as Timer0;

  components ActiveMessageC;
  components new AMSenderC(0xA4);

  Sht11C.Boot -> MainC.Boot;
  Sht11C.Leds -> LedsC;
  Sht11C.Timer0 -> Timer0;

  Sht11C.AMControl -> ActiveMessageC;
  Sht11C.AMSend -> AMSenderC;
  Sht11C.Packet -> AMSenderC;

  components new SensirionSht11C() as Sht11Ch0C;
  Sht11C.ReadTemp -> Sht11Ch0C.Temperature;
  Sht11C.ReadHumi -> Sht11Ch0C.Humidity;

  components new IlluAdcC() as Illu;
  Sht11C.ReadIllu -> Illu;

  components BatteryC;
  Sht11C.Battery -> BatteryC;
}
